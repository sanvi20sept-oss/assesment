# s and p 

A Pen created on CodePen.

Original URL: [https://codepen.io/Sanvi-Sharma-the-reactor/pen/yyYwgJe](https://codepen.io/Sanvi-Sharma-the-reactor/pen/yyYwgJe).

